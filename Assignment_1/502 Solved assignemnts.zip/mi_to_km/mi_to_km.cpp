// --- Your code here
#include <cmath>
#include <iomanip>
#include <iostream>
#include <fstream>

int main()
{
    double mi,km;
    std::cout << "Enter the number of miles that has to be converted to km" << std::endl; 
    std::cin >> mi;
    km=mi*1.609344;
    std::cout << std::fixed << std::setprecision(4);
    std::cout << mi << " miles is equal to " << km << " kilometers" << std::endl;
    return 0 ;
}


// ---