#include <cmath>
#include <iomanip>
#include <iostream>
#include <fstream>

int main()
{
    double a, b, c;
    double r1, r2;
    std::cout << "Type in a, b, and c. Press 'Enter' between each\n";
    std::cin >> a;
    std::cin >> b;
    std::cin >> c;
    // std::cout << std::setprecision(4);
    // --- Your code here
        double discriminant = b * b - 4 * a * c;

    if (discriminant >= 0) {
        double r1 = (-b + std::sqrt(discriminant)) / (2 * a);
        double r2 = (-b - std::sqrt(discriminant)) / (2 * a);

          std::cout << std::fixed << std::setprecision(4);
        std::cout << "The roots are: " << r1 << " and " << r2 << std::endl;
    } else {
        std::cout << "The equation has complex roots." << std::endl;
    }

    return 0;

}